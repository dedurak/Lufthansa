package com.example.lufthansa.APIObjects;

import android.graphics.drawable.Drawable;

public class TtFlight {
    private String airportCode;
    private String statusOfFlight;
    private String timeToShow;
    private String flightNumber;
    private Drawable operatorLogo;

    public TtFlight(String airportCode, String statusOfFlight,
                  String timeToShow, String flightNumber,
                  Drawable operatorLogo) {
        this.airportCode = airportCode;
        this.statusOfFlight = statusOfFlight;
        this.timeToShow = timeToShow;
        this.flightNumber = flightNumber;
        this.operatorLogo = operatorLogo;
    }

    /**
     // getter methods
     */
    public String getAirportCode () { return airportCode; }
    public String getStatusOfFlight () { return statusOfFlight; }
    public String getTimeToShow () { return timeToShow; }
    public String getFlightNumber () { return flightNumber; }
    public Drawable getLogo() { return operatorLogo; }
}

