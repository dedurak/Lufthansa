# Lufthansa Group Flight Information

This is a small android application in production to search for all flights of Lufthansa Group. 
The Lufthansa Groups members are Lufthansa, Eurowings, Swiss and Austrian Airlines. 

The App fetches the data from the Lufthansa Public API. It is also possible to look for all venture and codeshare flights.
App will be published soon in Play Store for download. 

If you have any suggestions please contact me.
