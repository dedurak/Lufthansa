package com.example.lufthansa;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lufthansa.APIObjects.Airport;
import com.example.lufthansa.APIObjects.Airports.AirportList;
import com.example.lufthansa.APIObjects.Cities.CityList;
import com.example.lufthansa.APIObjects.TtFlight;
import com.example.lufthansa.MainFragments.Fragments.FlightInfoItemClickListener;

import java.util.ArrayList;

public class TimeTableAdapter extends RecyclerView.Adapter<TimeTableAdapter.TimeTableHolder> {

    private ArrayList<TtFlight> deps;
    private Context context;
    private static FlightInfoItemClickListener listener;

    // the constructor loads the data
    public TimeTableAdapter (Context context, FlightInfoItemClickListener listener, ArrayList<TtFlight> deps) {
        this.deps = deps;
        this.context = context;
        TimeTableAdapter.listener = listener;
    }


    public static class TimeTableHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

         // declare the items
        AppCompatImageView logo;
        TextView flightNo;
        TextView arrCode;
        TextView depTime;
        TextView status;

        public TimeTableHolder (View view) {
            super(view);

            logo = view.findViewById(R.id.depAirlineLogo);
            flightNo = view.findViewById(R.id.depFlightNumber);
            arrCode = view.findViewById(R.id.depArrCode);
            depTime = view.findViewById(R.id.depDepTime);
            status = view.findViewById(R.id.depResultStatus);

            view.setOnClickListener(this);
        }

        // implement onClick to call the numberinfo fragment to show the details of the departure flight
        @Override
        public void onClick (View v) {listener.recyclerClickListener(v, this.getLayoutPosition()); }
    }


    @Override
    public TimeTableAdapter.TimeTableHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);

        View depView = inflater.inflate(R.layout.departure_item, viewGroup, false);

        return new TimeTableHolder(depView);
    }


    @Override
    public void onBindViewHolder(TimeTableAdapter.TimeTableHolder viewHolder, int position) {

        TtFlight flight = deps.get(position);

        AppCompatImageView logo = viewHolder.logo;
        logo.setImageDrawable(flight.getLogo());

        TextView mFlightNo = viewHolder.flightNo;
        TextView mArrCode = viewHolder.arrCode;
        TextView mDepTime = viewHolder.depTime;
        TextView mStatus = viewHolder.status;

        mFlightNo.setText(flight.getFlightNumber());
        mArrCode.setText(CityList.getCityName(AirportList.getAirportCityCode(flight.getAirportCode())));
        mDepTime.setText(flight.getTimeToShow());
        mStatus.setText(flight.getStatusOfFlight());
    }


    @Override
    public int getItemCount() { return deps.size(); }
}
