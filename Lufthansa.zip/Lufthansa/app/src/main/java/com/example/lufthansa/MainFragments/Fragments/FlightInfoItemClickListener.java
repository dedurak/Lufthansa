package com.example.lufthansa.MainFragments.Fragments;

import android.view.View;

public interface FlightInfoItemClickListener {
    void recyclerClickListener(View v, int pos);
}
